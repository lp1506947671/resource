from django.apps import AppConfig


class VerifycationsConfig(AppConfig):
    name = 'verifycations'
