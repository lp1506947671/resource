# 列表页中每页显示多少条数据
SKU_LIST_PER_PAGE = 5
